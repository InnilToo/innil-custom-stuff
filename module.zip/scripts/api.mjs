import { drawCircle } from "./modules/animations.mjs";
import { gameTools } from "./modules/gameTools/_gameTools.mjs";
import {
  _checkTokenInTemplate,
  _getDocumentFromCompendium,
  _getTokenOwnerIds,
  _romanize,
  _selectContained,
  _targetTokens,
  _teleportTokens,
  _titleCard,
  _whisperPlayers,
} from "./modules/innil_functions.mjs";
import { ITEMACRO } from "./modules/itemMacros.mjs";
import { INNIL_SOCKETS } from "./modules/sockets.mjs";

export class api {
  static register() {
    globalThis.INNIL = {
      token: {
        teleport: _teleportTokens,
        target: _targetTokens,
        getOwnerIds: _getTokenOwnerIds,
        contained: _checkTokenInTemplate,
        selectContained: _selectContained,
      },
      utils: {
        getDocument: _getDocumentFromCompendium,
        roman: _romanize,
        whisperPlayers: _whisperPlayers,
        titleCard: _titleCard,
        drawCircle: drawCircle,
        loadTextureForAll: INNIL_SOCKETS.loadTextureForAll,
        createTiles: INNIL_SOCKETS.createTiles,
        awardLoot: INNIL_SOCKETS.awardLoot,
        updateToken: INNIL_SOCKETS.updateTokens,
        grantItems: INNIL_SOCKETS.grantItems,
        healToken: INNIL_SOCKETS.healToken,
        ...gameTools,
      },
      ITEMACRO,
    };
  }
}

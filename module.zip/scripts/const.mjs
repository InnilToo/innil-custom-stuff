export const MODULE_NAME = "innil-custom-stuff";
export const MODULE_TITLE = "Innil's Custom Stuff";
export const MODULE_TITLE_SHORT = "INNIL";
